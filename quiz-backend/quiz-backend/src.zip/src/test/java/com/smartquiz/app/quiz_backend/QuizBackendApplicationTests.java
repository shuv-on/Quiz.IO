package com.smartquiz.app.quiz_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
